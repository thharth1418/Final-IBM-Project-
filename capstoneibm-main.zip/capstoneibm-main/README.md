Lab 1: Collecting the data
